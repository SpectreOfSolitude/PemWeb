<?php $__env->startSection('content'); ?>
   <h1> DOTA 2 HERO PICKER </h1> 
   <p>Aturkan hero yang ingin ditambahkan</p>
   <form action="<?php echo e(route('crud.create')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="title" class="form-label">Nama Hero</label>
            <input type="text" class="form-control" id="title" name="title" required>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label">Attribute Hero</label>
            <input class="form-control" id="description" name="description" rows="3" required></input>
        </div>
        <button type="submit" class="btn btn-primary">Tambah Hero</button>
    </form>
    <table class="table mt-3">
        <h1>HERO YANG SUDAH TERDAFTAR</h1>
        <thead>
            <tr>
                <th>Nama Hero</th>
                <th>Attribute</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($datum->hero_name); ?></td>
                    <td><?php echo e($datum->hero_attribute); ?></td>
                    <td>
                        <a href="" class="btn btn-warning">Edit</a>
                        <form action="" method="POST" style="display:inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\akasy\OneDrive\Kuliah\Semester 5\Pemrograman Web\Praktikum\Modul 11\postTest\resources\views/welcome.blade.php ENDPATH**/ ?>